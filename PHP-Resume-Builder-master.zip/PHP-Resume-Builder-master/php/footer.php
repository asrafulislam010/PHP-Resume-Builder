<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
	.footer{background:rgba(200,200,200,0.5);
      color: white;
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      text-align: center;
      padding: 10px;
}
	</style>
</head>
<body>
<div class="footer">
<footer>Copyright &copy Biography,2018</footer>
</div>
</body>
</html>